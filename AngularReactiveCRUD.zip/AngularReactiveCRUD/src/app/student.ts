export class Student {
    /**
     *
     */
    constructor(
        public name?:string,
        public age?:number,
        public email?:string,
        public gender?:string,
        public country?:string,
        public accept?:boolean,
        public hobbies?:string,
       
    ) {
        
    }
}
