export class Todo {
    id:number=0;
    task:string='';
    developer:string='';
}
