import { Component } from '@angular/core';
import { Todo } from 'src/app/model/todo';
import { TaskService } from 'src/app/services/task.service';
import Swal from 'sweetalert2';
//import Swal from 'sweetalert2';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
  //Create variables for hold value
  taskObj: Todo = new Todo();
  taskArr: Todo[] = [];
  addTaskData: string = '';
  addTaskDeveloper:string='';
  editTaskDeveloper='';
  editTaskData:string='';
  constructor(private api: TaskService) { }
  ngOnInit(): void {
    this.editTaskData='';
    this.editTaskDeveloper='';
    this.addTaskData='';
    this.addTaskDeveloper='';
    this.taskObj = new Todo();
    this.taskArr=[];
    this.getAllTask();
  }
  //Create task data
  addTask() {
    this.taskObj.task = this.addTaskData;
    this.taskObj.developer=this.addTaskDeveloper;
    this.api.addTask(this.taskObj).subscribe(res => {
      Swal.fire('Hi','Task added successfully','success');
      // Swal.fire({
      //   position: 'center',
      //   icon: 'success',
      //   title: 'Task added successfully',
      //   showConfirmButton: false,
      //   timer: 1500
      // })
      this.ngOnInit();
      this.addTaskData='';
      this.addTaskDeveloper='';
    }, err => {
      alert(err);
    }
    )
  }
  //Get all task data

  getAllTask() {
    this.api.getAllTask().subscribe(res => {
      this.taskArr = res;
    }, err => { alert('Unable to fine data') })
  }

  //Edit Task
  editTask() {
    this.taskObj.task=this.editTaskData;
    this.taskObj.developer=this.editTaskDeveloper;
    this.api.editTask(this.taskObj).subscribe(res => {
      Swal.fire('Hi','Task updated successfully','success');
      // Swal.fire({
      //   position: 'center',
      //   icon: 'success',
      //   title: 'Task updated successfully',
      //   showConfirmButton: false,
      //   timer: 1500
      // })
      this.ngOnInit();
    }, err => { alert('unable to update task'); })
  }

  deleteTask(task:Todo) {
    this.api.deleteTask(task).subscribe(res => { 
      this.ngOnInit();
    }, err => { alert('Failed to Delete Data') })
  }

  callEdit(task:Todo){
    this.taskObj=task;
    this.editTaskData=task.task;
    this.editTaskDeveloper=task.developer;
  }

}
