import { compileNgModule } from '@angular/compiler';
import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Student } from '../student';

@Component({
  selector: 'app-tdf',
  templateUrl: './tdf.component.html',
  styleUrls: ['./tdf.component.css']
})
export class TdfComponent {
  std = new Student();
  selectedHobbies:string[]=[];
  constructor(){
    this.std.country="";
  }
save(formData:any){
 //console.log(formData);
//  const stud = new Student(formData.name, formData.age, formData.email)
//  console.log(stud);
console.log(this.std);
console.log(this.selectedHobbies);
}
onChange(e:any){
console.log(e.target.value);
console.log(e.target.checked);
let selectedValue = e.target.value;
let checked = e.target.checked;
if(checked)
{
  this.selectedHobbies.push(selectedValue);
}
else
{  
  let index = this.selectedHobbies.indexOf(selectedValue);
  this.selectedHobbies.splice(index,1);
}

}

ResetForm(my_form:NgForm){
my_form.resetForm();
this.selectedHobbies=[];
}
}
