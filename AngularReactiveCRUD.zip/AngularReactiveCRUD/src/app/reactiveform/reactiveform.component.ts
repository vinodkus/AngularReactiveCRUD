import { Component } from '@angular/core';
import { FormArray, FormControl, FormGroup,Validator, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css']
})
export class ReactiveformComponent {
  hobbiesArray:string[]=['Reading','Writing','Singing'];
constructor(){

}
  signupForm = new FormGroup({
    name:new FormControl('',[Validators.required,Validators.minLength(3),Validators.maxLength(20)]),
    age:new FormControl('',[Validators.required,Validators.min(10),Validators.max(50)]),
    email:new FormControl('',[Validators.required,Validators.email]),
    gender:new FormControl('',[Validators.required]),
    country:new FormControl('',[Validators.required]),
    accept:new FormControl(false,[Validators.requiredTrue]),
    hobbies:new FormArray([],[Validators.required])
  })
  handleSubmit(){
    console.log(this.signupForm.value)
  }
  get f(){
    return this.signupForm.controls;
  }
  onChange(e:any){
    console.log(e.target.value,e.target.checked);
    let checkedValue = e.target.value;
    let checked = e.target.checked;
    const checkedArray = this.signupForm.get('hobbies') as FormArray;
    if(checked)
    {
      checkedArray.push(new FormControl(checkedValue));
    }
    else
    {
     let i:number=0;
     checkedArray.controls.forEach(item => {
      if(item.value ==  checkedValue)
      {
        checkedArray.removeAt(i);
      }
      i++;
     });

    }
  }
}
